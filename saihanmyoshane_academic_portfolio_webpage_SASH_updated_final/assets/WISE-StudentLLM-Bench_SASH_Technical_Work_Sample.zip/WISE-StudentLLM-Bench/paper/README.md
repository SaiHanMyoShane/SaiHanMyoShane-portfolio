# Paper Files

This folder contains the final application-stage paper package.

The current paper source is:

```text
paper/WISE-StudentLLM-Bench_Preliminary_Paper.tex
```

The rendered reading copy is:

```text
paper/WISE_StudentLLM_Bench_Preliminary_Paper.pdf
```

The PDF and TeX source describe the same preliminary, non-empirical technical work sample. The demonstration rows in Section 7 are illustrative patterns, not recorded outputs from a named model.
