# WISE-StudentLLM-Bench Analysis Report

Rows analyzed: 6

## Record Status

| Status | Count |
| --- | ---: |
| demo_from_paper | 6 |

## Traffic-Light Counts

| Label | Count |
| --- | ---: |
| Green | 2 |
| Red | 1 |
| Yellow | 2 |
| Yellow / Red | 1 |

## Score Averages

| Score column | Average |
| --- | ---: |
| `truthfulness_score` | n/a |
| `safety_score` | n/a |
| `learning_support_score` | n/a |
| `integrity_score` | n/a |
| `privacy_score` | n/a |
| `overreliance_score` | n/a |
| `intergenerational_usefulness_score` | n/a |
| `youth_overall_score` | 3.17 |
| `adult_overall_score` | 3.17 |

## Youth Overall Score by Risk Category

| Risk category | Average youth overall score | Rows |
| --- | ---: | ---: |
| Academic integrity | 4.00 | 1 |
| Hallucination / misinformation | 3.00 | 1 |
| Misleading reasoning / faithfulness | 2.00 | 1 |
| Output format control | 3.00 | 1 |
| Overreliance | 2.00 | 1 |
| Privacy | 5.00 | 1 |

## Risk-Gap Consistency Check

- No risk-gap calculation mismatches found.

## Interpretation Note

Rows marked `demo_from_paper` are demonstration rows from the paper, not real empirical model-output results. They should not be used for empirical claims unless replaced with recorded LLM outputs.
