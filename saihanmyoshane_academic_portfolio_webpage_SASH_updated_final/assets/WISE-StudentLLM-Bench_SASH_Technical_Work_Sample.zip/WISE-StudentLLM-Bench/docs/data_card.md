# Data Card

## Dataset Name

WISE-StudentLLM-Bench prompt and demonstration scoring data.

## Intended Use

This data supports a preliminary student-facing LLM safety evaluation artifact. It is intended for:

- demonstrating prompt design
- recording model outputs
- applying a 1-5 rubric
- comparing youth and adult reviewer judgments
- producing simple descriptive summaries

It is not intended for training a model or making broad claims about model safety.

## Files

| File | Description |
| --- | --- |
| `data/prompts.csv` | Safe student-facing prompt scenarios. |
| `data/scored_responses.csv` | Demonstration scoring rows from the paper. Use as demonstration rows only unless replaced with recorded model-output rows for empirical use. |
| `data/model_run_log.csv` | Template for documenting actual LLM runs. |

## Prompt Sources

Rows marked `paper_representative` come directly from the representative prompt table in the paper. Rows marked `repo_completion_from_paper_scope` are additional safe prompts drafted to complete the paper's stated 20-30 prompt application scope.

The current CSV has nine prompt-category labels. These should be understood as seven core student-facing risk categories plus two non-risk support categories: `Normal learning support` as a baseline/control category and `Intergenerational guidance` as a protocol/literacy category. This is not a claim that the artifact is a validated benchmark taxonomy.

## Sensitive Data

No real student records, report cards, private chats, personal documents, or contact details should be included. Privacy prompts use hypothetical scenarios only.

## Known Limitations

- The prompt set is small.
- The prompt set is English-first.
- Demonstration scored rows are not real model-output experiments.
- Manual scores can reflect reviewer judgment and bias.
- The current package is an application-stage artifact, not a validated benchmark.

