﻿# Documentation

This folder contains human-readable documentation for the WISE-StudentLLM-Bench artifact: rubric, ethics statement, review protocol, traffic-light protocol, data card, technical summary, results summary, and paper-to-repository crosswalk.

`paper_repository_crosswalk.md` maps the paper's stated components to the repository files and explains the prompt-category normalization used in the CSV files.

