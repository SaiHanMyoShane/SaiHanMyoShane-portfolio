# Paper-Repository Crosswalk

This crosswalk records how the paper `paper/WISE-StudentLLM-Bench_Preliminary_Paper.tex` maps to the final application-stage repository. It is intended to make the artifact transparent and easy to review.

## Component Alignment

| Paper component or claim | Repository implementation | Status |
| --- | --- | --- |
| Student-facing prompt dataset | `data/prompts.csv` contains 30 safe student-facing prompts. | Present |
| Representative paper prompts | The 15 prompts displayed in Section 5 are marked `paper_representative`. | Present |
| Completion of the 20-30 prompt scope | 15 additional prompts are marked `repo_completion_from_paper_scope`. | Present |
| Seven core risk categories | Hallucination/misinformation, overreliance, academic integrity, privacy, unsafe advice/boundary, misleading reasoning/faithfulness, and output-format control. | Present |
| Two support categories | Normal learning support provides baseline cases; intergenerational guidance supports the review protocol. | Present |
| 1-5 scoring rubric | `docs/rubric.md` defines the scale and seven scoring dimensions used by the paper. | Present |
| Minimal recording schema | `data/scored_responses.csv` contains the response and scoring fields; `data/model_run_log.csv` is the run-metadata template. | Present |
| Section 7 sample table | `data/scored_responses.csv` contains the six matching rows. | Present; demonstration only |
| Intergenerational review method | `docs/intergenerational_review_protocol.md` defines the youth technical and adult policy/education/ethics lenses. | Present |
| Green/Yellow/Red protocol | `docs/traffic_light_protocol.md` converts evaluation judgments into student-facing action guidance. | Present |
| Ethics and limitations | `docs/ethics_statement.md`, `docs/data_card.md`, and `docs/results_summary.md` state privacy boundaries, limitations, and non-empirical status. | Present |
| Descriptive analysis | `scripts/analysis.py` reads the scoring CSV and regenerates `outputs/analysis_report.md`. | Present and reproducible |
| Paper source and reading copy | The canonical TeX source and rendered PDF are both included in `paper/`. | Present |

## Category-Label Normalization

The paper describes 5-7 core risk categories. The CSV has nine category labels because it contains seven core risk categories and two support categories:

- `Normal learning support` is a baseline/control category.
- `Intergenerational guidance` is a review-protocol and AI-safety-literacy category.

Section 7 uses several shortened display labels for table compactness. The CSV uses the fuller labels below:

| Section 7 display label | Repository label |
| --- | --- |
| `Misinformation` | `Hallucination / misinformation` |
| `Output format` | `Output format control` |
| `Misleading reasoning` | `Misleading reasoning / faithfulness` |

Section 7 also retains one provisional `Yellow / Red` boundary label. The repository preserves it exactly for paper alignment and documents it in `docs/rubric.md` and `docs/traffic_light_protocol.md`; it is not treated as a fourth protocol level.

## Demonstration-Only Status

The six rows in `data/scored_responses.csv` are marked `demo_from_paper` and use `DEMO_NOT_REAL_MODEL_OUTPUT` as the model name. They demonstrate the schema and scoring logic; they are not empirical evidence about a model. `data/model_run_log.csv` is intentionally an empty template until actual model runs are conducted.

## Non-Claims

The paper and repository do not claim that this artifact is:

- a validated benchmark;
- a completed empirical model evaluation;
- evidence that a named LLM is safe or unsafe;
- a school policy or safety guarantee; or
- a model-training or fine-tuning project.

The accurate claim is narrower: WISE-StudentLLM-Bench proposes and demonstrates a preliminary student-facing LLM safety evaluation and AI safety literacy framework that can later be expanded with recorded model outputs.
