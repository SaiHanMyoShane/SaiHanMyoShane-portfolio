# Ethics Statement

WISE-StudentLLM-Bench is a preliminary application-stage project. It is not a validated benchmark, not a school policy, and not a safety guarantee.

## Scope

The project evaluates student-facing LLM responses for ordinary educational risk boundaries:

- hallucination and misinformation
- overreliance
- academic integrity
- privacy leakage
- unsafe advice or weak boundaries
- misleading reasoning or weak faithfulness
- output-format control
- responsible learning support

The project does not test frontier dangerous capabilities and does not include harmful operational instructions.

## Data Handling

The prompt dataset must not include:

- real student records
- real report cards
- full names of uninvolved students
- private chats
- contact details
- medical, legal, or other sensitive personal information
- prompts that teach harmful behavior

Privacy-related prompts use hypothetical or placeholder scenarios only.

## Student Safety Boundaries

The traffic-light protocol is a learning aid. It does not replace:

- school policy
- teacher guidance
- parental or guardian judgment
- platform rules
- professional medical, legal, psychological, or safety advice

When a response involves health, safety, privacy, harassment, self-harm, legal risk, or serious school consequences, the student-facing action should be to stop, verify, and involve a trusted adult, teacher, or qualified professional.

## Academic Integrity

The project should not normalize hidden assignment writing, plagiarism, cheating, or evasion of school rules. A safe response may help a student understand, outline, revise, cite, verify, or reflect, but it should not complete dishonest work for the student.

## Intergenerational Review

The youth and adult reviewers may disagree. Such disagreement is not treated as an error. It is part of the method because young technical learners and adult policy/education reviewers may notice different risks in the same output.

## Limitations

A 20-30 prompt dataset cannot represent all student use cases, subjects, languages, schools, cultures, or model behaviors. Manual scoring may reflect reviewer bias. A two-person intergenerational review cannot generalize to all youth or adult perspectives.

The appropriate claim is narrow:

> WISE-StudentLLM-Bench proposes and demonstrates a preliminary student-facing LLM safety evaluation and AI safety literacy framework that can be expanded into a more rigorous final project.

