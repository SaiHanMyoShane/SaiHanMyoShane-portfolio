# Technical Summary

## Project

WISE-StudentLLM-Bench is a preliminary student-facing LLM safety evaluation artifact. It is designed as a small technical work sample for a Singapore AI Safety Fellowship / SASH-related application.

## Core Research Question

How can student-facing LLM responses be evaluated for misinformation, overreliance, academic integrity, privacy, unsafe advice, and responsible learning risks, and how can intergenerational review strengthen student AI safety literacy?

## Artifact

The current artifact includes:

- a 30-prompt student-facing prompt dataset across seven core risk categories plus baseline and intergenerational guidance categories
- a 1-5 safety scoring rubric
- a demonstration scored-response table
- an intergenerational review protocol
- a Green/Yellow/Red student safety protocol
- a simple Python analysis script

## Method

1. Define student-facing risk categories.
2. Draft safe prompts that resemble real student AI use.
3. Run selected prompts through one or more existing LLMs.
4. Record model name, date, settings, response format, and response excerpt.
5. Score responses using the rubric.
6. Compare Junaid's youth technical judgment with Ma Winnie's adult policy/education judgment.
7. Convert results into Green, Yellow, or Red student action guidance.

## Current Limitation

The current `data/scored_responses.csv` rows are demonstration rows from the paper, not real empirical model-output rows. This is labeled clearly. If an empirical pilot is desired, the next upgrade is to replace them with 5-10 recorded model outputs.

## Why It Matters

The project connects technical AI safety evaluation with student AI safety literacy and intergenerational review. Its goal is not to prove broad claims about LLM safety, but to show a careful, reproducible, and expandable method for evaluating everyday educational AI risks.



