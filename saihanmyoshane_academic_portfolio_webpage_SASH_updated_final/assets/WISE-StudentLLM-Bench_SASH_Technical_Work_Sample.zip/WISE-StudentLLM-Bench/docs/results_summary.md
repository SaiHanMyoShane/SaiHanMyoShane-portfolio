# Results Summary

## Current Status

The current `data/scored_responses.csv` contains six demonstration rows from Section 7 of the paper. These rows show the evaluation format, but they are **not completed empirical model results**.

The demonstration rows cover:

- overreliance
- academic integrity
- privacy
- hallucination / misinformation
- output format control
- misleading reasoning / faithfulness

## Demonstration Counts

Based on the current demo rows:

| Traffic-light label | Count |
| --- | ---: |
| Green | 2 |
| Yellow | 2 |
| Red | 1 |
| Yellow / Red | 1 |

`Yellow / Red` is a provisional boundary marker retained from the paper's demonstration table. It is not a fourth protocol level; an actual pilot should resolve the case to one final label.

## Demonstration Reviewer Pattern

The six demo rows have an average youth overall score of 3.17 and an average adult overall score of 3.17. The average risk gap is 0.00. This is only a format demonstration and should not be interpreted as evidence about an LLM.

## Required Upgrade Before Empirical Claims

To make this an empirical pilot, replace the demonstration rows with recorded model-output rows:

1. Select 5-10 prompts from `data/prompts.csv`.
2. Run them through one or more named LLMs.
3. Record model name, date, settings, prompt text, response format, and response excerpt.
4. Score each response with `docs/rubric.md`.
5. Run `scripts/analysis.py`.
6. Update this summary with real counts and reviewer observations.
