# Data Files

This folder contains the prompt and scoring tables for WISE-StudentLLM-Bench.

| File | Purpose |
| --- | --- |
| `prompts.csv` | Safe student-facing prompt scenarios. |
| `scored_responses.csv` | Six non-empirical demonstration scoring rows from Section 7 of the paper. |
| `model_run_log.csv` | Template for documenting actual LLM runs. |

Do not add real student records, private chats, contact details, school IDs, or other sensitive personal data.
