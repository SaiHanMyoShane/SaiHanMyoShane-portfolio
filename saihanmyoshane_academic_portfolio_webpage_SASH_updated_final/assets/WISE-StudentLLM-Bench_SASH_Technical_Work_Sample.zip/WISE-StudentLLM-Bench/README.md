# WISE-StudentLLM-Bench

**Preliminary Student-Facing LLM Safety Evaluation and AI Safety Literacy Framework**

This repository packages the technical artifact described in `paper/WISE-StudentLLM-Bench_Preliminary_Paper.tex`: a small, student-facing LLM safety evaluation project prepared as a technical work sample for a Singapore AI Safety Fellowship / SASH-related application.

The project provides a structured method for evaluating existing LLM responses. It does **not** train, fine-tune, or build an LLM.

**Paper status:** the repository includes both the canonical TeX source and the matching rendered PDF. The PDF is the submission-ready reading copy; the TeX file is the editable source.

## GitHub Upload Note

Use this `WISE-StudentLLM-Bench` folder as the GitHub repository root. Do not upload the outer submission-package folder or the ZIP file as repository contents.

## Purpose

Students increasingly use large language models as explanation engines, writing helpers, coding assistants, homework-support tools, study companions, and advice sources. WISE-StudentLLM-Bench treats this as a practical AI safety evaluation problem: when an LLM response sounds fluent and helpful, does it support safe learning, or does it create risks such as misinformation, overreliance, academic integrity problems, privacy leakage, unsafe advice, or weakened human judgment?

WISE means **Wisdom-Informed Safety Education**. In this project, WISE connects three layers:

1. **Technical core:** a prompt dataset, response-recording schema, scoring rubric, reviewer notes, and simple descriptive analysis.
2. **Educational outcome:** student AI safety literacy: knowing when to use, verify, question, or reject an LLM response.
3. **Socio-technical method:** intergenerational review by Junaid as a youth technical learner and Ma Winnie as an adult policy, education, ethics, and governance reviewer.

## Repository Contents

| Path | Purpose |
| --- | --- |
| `paper/WISE-StudentLLM-Bench_Preliminary_Paper.tex` | Canonical editable TeX source for the paper. |
| `paper/WISE_StudentLLM_Bench_Preliminary_Paper.pdf` | Rendered paper for reading and application submission. |
| `data/prompts.csv` | Student-facing prompt dataset. Includes the paper's representative prompts plus additional safe draft prompts that complete the 20-30 prompt application scope. |
| `data/scored_responses.csv` | Demonstration scoring table based on Section 7 of the paper. These rows are labeled as demo rows, not real empirical model outputs. |
| `data/model_run_log.csv` | Template for recording actual LLM runs. |
| `docs/rubric.md` | 1-5 scoring rubric for truthfulness, safety, learning support, academic integrity, privacy, overreliance, and intergenerational usefulness. |
| `docs/ethics_statement.md` | Data handling, privacy, safety boundaries, and limitations. |
| `docs/intergenerational_review_protocol.md` | Review process for comparing youth technical judgment with adult policy/education judgment. |
| `docs/traffic_light_protocol.md` | Student-facing Green/Yellow/Red action guide. |
| `docs/data_card.md` | Short documentation for the prompt and scoring data. |
| `docs/technical_summary.md` | One-page-style summary of the artifact, method, and current limitation. |
| `docs/paper_repository_crosswalk.md` | Crosswalk from the paper's claims and components to the repository files. |
| `docs/results_summary.md` | Current summary of the demo table and what must change once real outputs are recorded. |
| `scripts/analysis.py` | Standard-library Python script for simple descriptive analysis. |
| `outputs/analysis_report.md` | Generated output from `scripts/analysis.py`. |

## Current Status

This is an **application-stage technical work sample**. The artifact is intentionally modest:

- 30 safe student-facing prompts
- 7 core student-facing risk categories plus baseline and intergenerational guidance prompt categories
- 1-5 scoring rubric
- 6 demonstration scored rows from the paper
- simple descriptive analysis code
- ethics and documentation files

The current scored rows are intentionally labeled as **demonstration rows**. They show the evaluation format, but they are not completed empirical model-output results and must not be presented as such.

## How To Use

1. Review `data/prompts.csv`.
2. Choose 5-10 prompts for a first pilot.
3. Run the selected prompts through one or more LLMs under fixed conditions.
4. Record model name, date, prompt text, settings, response format, and response excerpt in `data/scored_responses.csv` and `data/model_run_log.csv`.
5. Score each response using `docs/rubric.md`.
6. Have Junaid and Ma Winnie score the same rows independently.
7. Run:

```bash
python scripts/analysis.py
```

8. Review the generated summary in `outputs/analysis_report.md`.

## What This Project Does Not Claim

This project is not a validated benchmark and should not be used to make broad claims about any model. A small prompt set cannot represent all students, subjects, languages, schools, cultures, or model behaviors. The purpose is to demonstrate a careful, transparent, and expandable evaluation method.

## Reproducibility

The analysis uses only the Python standard library. From the repository root, run:

```bash
python scripts/analysis.py
```

The command reads `data/scored_responses.csv` and regenerates `outputs/analysis_report.md`. With the included demonstration rows, the report contains six analyzed rows, two Green cases, two Yellow cases, one Red case, and one Yellow / Red case.

## Privacy and Publication Notes

- Do not upload real student records, private chats, school IDs, contact details, or sensitive personal information.
- Do not add a resume or portfolio file unless it has been privacy-reviewed and intentionally selected for public release.
- Do not present demo rows as real empirical model-output results.
- If real model outputs are added, update `data/scored_responses.csv`, `data/model_run_log.csv`, `docs/results_summary.md`, `outputs/analysis_report.md`, and the paper's Section 7 together.

## License and Reuse

No open-source license has been selected. Copyright and reuse rights therefore remain with the project owner unless permission is granted separately.
