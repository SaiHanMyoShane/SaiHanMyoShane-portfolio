﻿# Scripts

Run the analysis script from the repository root:

```bash
python scripts/analysis.py
```

The script uses only the Python standard library. It reads `data/scored_responses.csv` and writes `outputs/analysis_report.md`.
