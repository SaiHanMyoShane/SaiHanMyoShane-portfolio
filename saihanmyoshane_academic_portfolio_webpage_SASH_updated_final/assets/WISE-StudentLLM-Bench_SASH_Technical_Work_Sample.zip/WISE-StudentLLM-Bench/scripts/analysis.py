"""Simple analysis for WISE-StudentLLM-Bench.

This script intentionally uses only the Python standard library so it can run
in a basic environment. It reads data/scored_responses.csv, summarizes
traffic-light labels, computes available score averages, checks risk-gap
consistency, and writes outputs/analysis_report.md.
"""

from __future__ import annotations

import csv
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean


ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
OUTPUT_DIR = ROOT / "outputs"
SCORED_RESPONSES = DATA_DIR / "scored_responses.csv"
SUMMARY_REPORT = OUTPUT_DIR / "analysis_report.md"

SCORE_COLUMNS = [
    "truthfulness_score",
    "safety_score",
    "learning_support_score",
    "integrity_score",
    "privacy_score",
    "overreliance_score",
    "intergenerational_usefulness_score",
    "youth_overall_score",
    "adult_overall_score",
]


def parse_number(value: str) -> float | None:
    text = (value or "").strip()
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def load_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def average(values: list[float]) -> float | None:
    if not values:
        return None
    return mean(values)


def format_average(value: float | None) -> str:
    if value is None:
        return "n/a"
    return f"{value:.2f}"


def check_risk_gaps(rows: list[dict[str, str]]) -> list[str]:
    warnings: list[str] = []
    for row in rows:
        youth = parse_number(row.get("youth_overall_score", ""))
        adult = parse_number(row.get("adult_overall_score", ""))
        recorded_gap = parse_number(row.get("risk_gap", ""))
        if youth is None or adult is None or recorded_gap is None:
            continue
        expected_gap = adult - youth
        if abs(expected_gap - recorded_gap) > 1e-9:
            warnings.append(
                f"{row.get('prompt_id', 'unknown')}: recorded risk_gap "
                f"{recorded_gap:g}, expected {expected_gap:g}"
            )
    return warnings


def summarize(rows: list[dict[str, str]]) -> str:
    traffic_counts = Counter(row.get("traffic_light", "").strip() or "Unlabeled" for row in rows)
    status_counts = Counter(row.get("record_status", "").strip() or "unknown" for row in rows)

    score_averages: dict[str, float | None] = {}
    for column in SCORE_COLUMNS:
        values = [value for row in rows if (value := parse_number(row.get(column, ""))) is not None]
        score_averages[column] = average(values)

    category_scores: dict[str, list[float]] = defaultdict(list)
    for row in rows:
        score = parse_number(row.get("youth_overall_score", ""))
        if score is not None:
            category_scores[row.get("risk_category", "Uncategorized")].append(score)

    gap_warnings = check_risk_gaps(rows)

    lines: list[str] = []
    lines.append("# WISE-StudentLLM-Bench Analysis Report")
    lines.append("")
    lines.append(f"Rows analyzed: {len(rows)}")
    lines.append("")
    lines.append("## Record Status")
    lines.append("")
    lines.append("| Status | Count |")
    lines.append("| --- | ---: |")
    for status, count in sorted(status_counts.items()):
        lines.append(f"| {status} | {count} |")
    lines.append("")
    lines.append("## Traffic-Light Counts")
    lines.append("")
    lines.append("| Label | Count |")
    lines.append("| --- | ---: |")
    for label, count in sorted(traffic_counts.items()):
        lines.append(f"| {label} | {count} |")
    lines.append("")
    lines.append("## Score Averages")
    lines.append("")
    lines.append("| Score column | Average |")
    lines.append("| --- | ---: |")
    for column, value in score_averages.items():
        lines.append(f"| `{column}` | {format_average(value)} |")
    lines.append("")
    lines.append("## Youth Overall Score by Risk Category")
    lines.append("")
    lines.append("| Risk category | Average youth overall score | Rows |")
    lines.append("| --- | ---: | ---: |")
    for category, values in sorted(category_scores.items()):
        lines.append(f"| {category} | {format_average(average(values))} | {len(values)} |")
    lines.append("")
    lines.append("## Risk-Gap Consistency Check")
    lines.append("")
    if gap_warnings:
        for warning in gap_warnings:
            lines.append(f"- WARNING: {warning}")
    else:
        lines.append("- No risk-gap calculation mismatches found.")
    lines.append("")
    lines.append("## Interpretation Note")
    lines.append("")
    lines.append(
        "Rows marked `demo_from_paper` are demonstration rows from the paper, "
        "not real empirical model-output results. They should not be used "
        "for empirical claims unless replaced with recorded LLM outputs."
    )
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    rows = load_rows(SCORED_RESPONSES)
    report = summarize(rows)
    OUTPUT_DIR.mkdir(exist_ok=True)
    SUMMARY_REPORT.write_text(report, encoding="utf-8")
    print(report)
    print(f"\nWrote {SUMMARY_REPORT}")


if __name__ == "__main__":
    main()
